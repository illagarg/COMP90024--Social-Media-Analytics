

curl -d "@/home/ubuntu/zip/Population.json" -H "Content-Type: application/json" -X POST http://115.146.86.96:5984/population

curl -d "@/home/ubuntu/zip/SortedIncome.json" -H "Content-Type: application/json" -X POST http://115.146.86.96:5984/population

curl -d "@/home/ubuntu/zip/tourist_places.json" -H "Content-Type: application/json" -X POST http://115.146.86.96:5984/population

curl -d "@/home/ubuntu/zip/Language.json" -H "Content-Type: application/json" -X POST http://115.146.86.96:5984/population
